//
//  UserRepositoryViewModelTests.swift
//  AJ_GHUsers_ExTests
//
//  Created by Ankit Jahagirdar on 05/05/25.
//

import XCTest
@testable import AJ_GHUsers_Ex

class UserRepositoryViewModelTests: XCTestCase {
    
    var viewModel: UserRepositoryViewModel!
    var mockRepositoryAPI: MockGHRepositoryAPI!
    var mockUserAPI: MockGHUsersDetailsAPI!
    var mockUser: GHUser!
    
    override func setUp() {
        super.setUp()
        mockRepositoryAPI = MockGHRepositoryAPI()
        mockUserAPI = MockGHUsersDetailsAPI()
        mockUser = GHUser(login: "testUser", avatar_url: "https://example.com/avatar.png")
        viewModel = UserRepositoryViewModel(user: mockUser, repositoryAPI: mockRepositoryAPI, userAPI: mockUserAPI)
    }
    
    override func tearDown() {
        mockRepositoryAPI = nil
        mockUserAPI = nil
        mockUser = nil
        viewModel = nil
        super.tearDown()
    }
    
    // MARK: - Test Cases
    
    func testFetchUserDetailsSuccess() {
        let mockUserDetails = GHUserDetail(login: "Test User", avatar_url: "", name: "Test User", followers: 100, following: 50)
        mockUserAPI.userDetailsResult = .success(mockUserDetails)
        viewModel.userDetails = GHUserDetail(login: "Test User", avatar_url: "", name: "Name1", followers: 100, following: 50)
        
        let expectation = XCTestExpectation(description: "User details are fetched successfully")
        
        viewModel.onUserDetailsUpdated = {
            XCTAssertEqual(self.viewModel.userDetails?.name, "Test User")
            XCTAssertEqual(self.viewModel.userDetails?.followers, 100)
            XCTAssertEqual(self.viewModel.userDetails?.following, 50)
            expectation.fulfill()
        }
        
        viewModel.fetchUserDetails()
        
        wait(for: [expectation], timeout: 1.0)
    }
    
    func testFetchUserDetailsFailure() {
        let mockError = NSError(domain: "TestError", code: 1, userInfo: nil)
        mockUserAPI.userDetailsResult = .failure(mockError)
        mockUserAPI.userResult = .failure(mockError)
        
        let expectation = XCTestExpectation(description: "Error is handled correctly")
        
        viewModel.onError = { errorMessage in
            XCTAssertEqual(errorMessage, mockError.localizedDescription)
            expectation.fulfill()
        }
        
        viewModel.fetchUserDetails()
        
        wait(for: [expectation], timeout: 1.0)
    }
    
    func testFetchRepositoriesSuccess() {
        let mockRepositories = [
            GHRepository(name: "Repo1", language: "Swift", stargazers_count: 10, description: "", html_url: "", fork: false),
            GHRepository(name: "Repo2", language: "Objective-C", stargazers_count: 9, description: "", html_url: "", fork: true)
        ]
        mockRepositoryAPI.repositoriesResult = .success(mockRepositories)
        
        let expectation = XCTestExpectation(description: "Repositories are fetched successfully")
        
        viewModel.onRepositoriesUpdated = {
            XCTAssertEqual(self.viewModel.repositories.count, 1)
            XCTAssertEqual(self.viewModel.repositories.first?.name, "Repo1")
            XCTAssertEqual(self.viewModel.repositories.first?.language, "Swift")
            XCTAssertEqual(self.viewModel.repositories.first?.stargazers_count, 10)
            expectation.fulfill()
        }
        
        viewModel.fetchRepositories()
        
        wait(for: [expectation], timeout: 1.0)
    }
    
    func testFetchRepositoriesFailure() {
        let mockError = NSError(domain: "TestError", code: 1, userInfo: nil)
        mockRepositoryAPI.repositoriesResult = .failure(mockError)
        
        let expectation = XCTestExpectation(description: "Error is handled correctly")
        
        viewModel.onError = { errorMessage in
            XCTAssertEqual(errorMessage, mockError.localizedDescription)
            expectation.fulfill()
        }
        
        viewModel.fetchRepositories()
        
        wait(for: [expectation], timeout: 1.0)
    }
}

// MARK: - Mock Classes

class MockGHRepositoryAPI: GHRepositoryAPIProtocol {
    var repositoriesResult: Result<[GHRepository], Error> = .success([])
    
    func fetchRepositories(userName: String, completion: @escaping (Result<[GHRepository], Error>) -> Void) {
        completion(repositoriesResult)
    }
}

class MockGHUsersDetailsAPI: GHUsersAPIProtocol {
    var userDetailsResult: Result<GHUserDetail, Error> = .success(GHUserDetail(login: "Test User", avatar_url: "", name: "Test User", followers: 100, following: 50))
    var result: Result<[GHUser], Error> = .success([])
    var userResult: Result<GHUserDetail, Error> = .success(GHUserDetail(login: "Test User", avatar_url: "", name: "Test User", followers: 100, following: 50))
    
    func fetchUsers(completion: @escaping (Result<[GHUser], Error>) -> Void) {
        completion(result)
    }
    
    func fetchUserDetails(userName: String, completion: @escaping (Result<GHUserDetail, any Error>) -> Void) {
        completion(userResult)
    }
    
}
