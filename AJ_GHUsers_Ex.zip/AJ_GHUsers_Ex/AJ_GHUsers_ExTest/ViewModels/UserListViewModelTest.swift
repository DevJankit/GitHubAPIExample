//
//  UserListViewModelTest.swift
//  AJ_GHUsers_Ex
//
//  Created by Ankit Jahagirdar on 04/05/25.
//

import XCTest
@testable import AJ_GHUsers_Ex

class UserListViewModelTests: XCTestCase {
    
    var viewModel: UserListViewModel!
    var mockUsersAPI: MockGHUsersAPI!
    var mockRateLimitAPI: MockGHRateLimitAPI!
    
    override func setUp() {
        super.setUp()
        mockUsersAPI = MockGHUsersAPI()
        mockRateLimitAPI = MockGHRateLimitAPI()
        viewModel = UserListViewModel(usersAPI: mockUsersAPI, rateLimitAPI: mockRateLimitAPI)
    }
    
    override func tearDown() {
        mockUsersAPI = nil
        mockRateLimitAPI = nil
        viewModel = nil
        super.tearDown()
    }
    
    // MARK: - Test Cases
    
    func testFetchUsersSuccess() {
        let mockUsers = [GHUser(login: "user1", avatar_url: ""), GHUser(login: "user2", avatar_url: "")]
        mockUsersAPI.result = .success(mockUsers)
        
        let expectation = XCTestExpectation(description: "Users are fetched successfully")
        
        viewModel.onUsersUpdated = {
            XCTAssertEqual(self.viewModel.users.count, mockUsers.count)
            XCTAssertEqual(self.viewModel.users.first?.login, "user1")
            expectation.fulfill()
        }
        
        viewModel.fetchUsers()
        
        wait(for: [expectation], timeout: 1.0)
    }
    
    func testFetchUsersFailure() {
        let mockError = NSError(domain: "TestError", code: 1, userInfo: nil)
        mockUsersAPI.result = .failure(mockError)
        
        let expectation = XCTestExpectation(description: "Error is handled correctly")
        
        viewModel.onError = { errorMessage in
            XCTAssertEqual(errorMessage, mockError.localizedDescription)
            expectation.fulfill()
        }
        
        viewModel.fetchUsers()
        
        wait(for: [expectation], timeout: 1.0)
    }
    
    func testRateLimitExceeded() {
        let mockRateLimitResponse = GHRateLimitResponse(rate: GHRateLimitResponse.GHRate(remaining: 0))
        mockRateLimitAPI.result = .success(mockRateLimitResponse)
        
        let expectation = XCTestExpectation(description: "Rate limit exceeded error is handled")
        
        viewModel.onError = { errorMessage in
            XCTAssertEqual(errorMessage, "Rate limit exceeded. Please try again later.")
            expectation.fulfill()
        }
        
        viewModel.checkRateLimitAndFetchUsers()
        
        wait(for: [expectation], timeout: 1.0)
    }
    
    func testRateLimitFetchFailure() {
        let mockError = NSError(domain: "TestError", code: 1, userInfo: nil)
        mockRateLimitAPI.result = .failure(mockError)
        
        let expectation = XCTestExpectation(description: "Rate limit fetch error is handled")
        
        viewModel.onError = { errorMessage in
            XCTAssertEqual(errorMessage, "Error fetching rate limit: \(mockError.localizedDescription)")
            expectation.fulfill()
        }
        
        viewModel.checkRateLimitAndFetchUsers()
        
        wait(for: [expectation], timeout: 1.0)
    }
    
    func testRateLimitCheckAndFetchUsersSuccess() {
        let mockRateLimitResponse = GHRateLimitResponse(rate: GHRateLimitResponse.GHRate(remaining: 10))
        let mockUsers = [GHUser(login: "user1", avatar_url: ""), GHUser(login: "user2", avatar_url: "")]
        mockRateLimitAPI.result = .success(mockRateLimitResponse)
        mockUsersAPI.result = .success(mockUsers)
        
        let expectation = XCTestExpectation(description: "Users are fetched successfully after rate limit check")
        
        viewModel.onUsersUpdated = {
            XCTAssertEqual(self.viewModel.users.count, mockUsers.count)
            XCTAssertEqual(self.viewModel.users.first?.login, "user1")
            expectation.fulfill()
        }
        
        viewModel.checkRateLimitAndFetchUsers()
        
        wait(for: [expectation], timeout: 1.0)
    }
}

// MARK: - Mock Classes

class MockGHUsersAPI: GHUsersAPIProtocol {
    var result: Result<[GHUser], Error> = .success([])
    var userResult: Result<GHUserDetail, Error> = .success(GHUserDetail(login: "", avatar_url: "", name: "", followers: 0, following: 0))
    
    func fetchUsers(completion: @escaping (Result<[GHUser], Error>) -> Void) {
        completion(result)
    }
    
    func fetchUserDetails(userName: String, completion: @escaping (Result<GHUserDetail, any Error>) -> Void) {
        completion(userResult)
    }
    
}

class MockGHRateLimitAPI: GHRateLimitAPIProtocol {
    var result: Result<GHRateLimitResponse, Error> = .success(GHRateLimitResponse(rate: GHRateLimitResponse.GHRate(remaining: 10)))
    
    func fetchRateLimit(completion: @escaping (Result<GHRateLimitResponse, Error>) -> Void) {
        completion(result)
    }
}
