//
//  UserListVCTest.swift
//  AJ_GHUsers_Ex
//
//  Created by Ankit Jahagirdar on 05/05/25.
//

//
//  UserListVCTests.swift
//  AJ_GHUsers_ExTests
//
//  Created by Ankit Jahagirdar on 05/05/25.
//

import XCTest
@testable import AJ_GHUsers_Ex

class UserListVCTests: XCTestCase {
    
    var viewModel: MockUserListViewModel!
    var coordinator: MockUserListCoordinator!
    var viewController: UserListVC!
    
    override func setUp() {
        super.setUp()
        viewModel = MockUserListViewModel()
        coordinator = MockUserListCoordinator()
        viewController = UserListVC(viewModel: viewModel, coordinator: coordinator)
        _ = viewController.view
    }
    
    override func tearDown() {
        viewModel = nil
        coordinator = nil
        viewController = nil
        super.tearDown()
    }
    
    // MARK: - Test Cases
    
    func testLoaderIsShownWhenFetchingData() {
        viewController.fetchData()
        
        XCTAssertTrue(viewController.loader.isAnimating, "Loader should be animating when fetching data.")
    }
    
    func testTableViewReloadsWhenUsersAreUpdated() {
        viewModel.users = [GHUser(login: "user1", avatar_url: "https://example.com/avatar1.png")]
        
        viewModel.onUsersUpdated?()
        
        XCTAssertEqual(viewController.tableView.numberOfRows(inSection: 0), 1, "TableView should reload with the correct number of rows.")
    }
    
    func testErrorViewIsShownWhenNoUsersAvailable() {
        viewModel.users = []
        
        viewModel.onUsersUpdated?()
        
        XCTAssertFalse(viewController.errorView.isHidden, "Error view should be visible when no users are available.")
    }
    
    func testErrorViewIsShownWhenErrorOccurs() {
        let errorMessage = "An error occurred"
        
        viewModel.onError?(errorMessage)
        
        XCTAssertFalse(viewController.errorView.isHidden, "Error view should be visible when an error occurs.")
    }
    
    func testNavigationToUserRepositoryVC() {
        let mockUser = GHUser(login: "user1", avatar_url: "https://example.com/avatar1.png")
        viewModel.users = [mockUser]
        viewModel.onUsersUpdated?()
        
        let navigationController = UINavigationController(rootViewController: viewController)
        UIApplication.shared.keyWindow?.rootViewController = navigationController
        
        viewController.tableView.delegate?.tableView?(viewController.tableView, didSelectRowAt: IndexPath(row: 0, section: 0))
        
        XCTAssertTrue(coordinator.didNavigateToUserRepository, "Coordinator should handle navigation to UserRepositoryVC.")
    }
}

// MARK: - Mock Classes

class MockUserListViewModel: UserListViewModelProtocol {
    var users: [GHUser] = []
    var isLoading: ((Bool) -> Void)?
    var onUsersUpdated: (() -> Void)?
    var onError: ((String) -> Void)?
    
    func fetchUsers() {}
    func checkRateLimitAndFetchUsers() {}
}

class MockUserListCoordinator: UserListCoordinatorProtocol {
    var didNavigateToUserRepository = false
    
    func navigateToUserRepository(user: GHUser) {
        didNavigateToUserRepository = true
    }
}
