//
//  MockURLSession.swift
//  AJ_GHUsers_Ex
//
//  Created by Ankit Jahagirdar on 04/05/25.
//

import Foundation

class MockURLSession: URLSession {
    private let mockDataTask: MockURLSessionDataTask

    init(data: Data?, response: URLResponse?, error: Error?) {
        self.mockDataTask = MockURLSessionDataTask(data: data, response: response, error: error)
    }

    override func dataTask(
        with request: URLRequest,
        completionHandler: @escaping (Data?, URLResponse?, Error?) -> Void
    ) -> URLSessionDataTask {
        mockDataTask.completionHandler = completionHandler
        return mockDataTask
    }
}

class MockURLSessionDataTask: URLSessionDataTask {
    var completionHandler: ((Data?, URLResponse?, Error?) -> Void)?
    private let mockData: Data?
    private let mockResponse: URLResponse?
    private let mockError: Error?

    init(data: Data?, response: URLResponse?, error: Error?) {
        self.mockData = data
        self.mockResponse = response
        self.mockError = error
    }

    override func resume() {
        completionHandler?(mockData, mockResponse, mockError)
    }
}
