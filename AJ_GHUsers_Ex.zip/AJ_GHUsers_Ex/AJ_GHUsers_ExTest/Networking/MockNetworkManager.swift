//
//  MockNetworkManager.swift
//  AJ_GHUsers_Ex
//
//  Created by Ankit Jahagirdar on 04/05/25.
//

import Foundation
@testable import AJ_GHUsers_Ex

class MockNetworkManager: NetworkManagerProtocol {
    var mockResponse: Data?
    var mockError: Error?
    var result: Result<Any, Error>!

    func request<T: Decodable>(
        endpoint: String,
        method: String,
        parameters: [String: String]?,
        completion: @escaping (Result<T, Error>) -> Void
    ) {
        if let error = mockError {
            completion(.failure(error))
        } else if let data = mockResponse {
            do {
                let decodedData = try JSONDecoder().decode(T.self, from: data)
                completion(.success(decodedData))
            } catch {
                completion(.failure(error))
            }
        } else {
            completion(.failure(NetworkError.unknown))
        }
    }
}
