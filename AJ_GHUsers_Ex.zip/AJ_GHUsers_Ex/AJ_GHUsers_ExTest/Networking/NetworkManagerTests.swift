//
//  NetworkManagerTests.swift
//  AJ_GHUsers_Ex
//
//  Created by Ankit Jahagirdar on 04/05/25.
//

import XCTest
@testable import AJ_GHUsers_Ex

class NetworkManagerTests: XCTestCase {
    
    var networkManager: NetworkManager!
    var mockSession: MockURLSession!
    
    override func setUp() {
        super.setUp()
        mockSession = MockURLSession(data: nil, response: nil, error: nil)
        networkManager = NetworkManager(environment: .production, session: mockSession)
    }
    
    override func tearDown() {
        mockSession = nil
        networkManager = nil
        super.tearDown()
    }
    
    // MARK: - Test Cases
    
    func testSuccessfulAPICall() {
        let mockData = """
        {
            "name": "Test Repository",
            "language": "Swift",
            "stargazers_count": 100
        }
        """.data(using: .utf8)
        let mockResponse = HTTPURLResponse(
            url: URL(string: "https://api.github.com")!,
            statusCode: 200,
            httpVersion: nil,
            headerFields: nil
        )
        let mockSession = MockURLSession(data: mockData, response: mockResponse, error: nil)
        let networkManager = NetworkManager(environment: .production, session: mockSession)
        
        let expectation = XCTestExpectation(description: "API call succeeds")
        
        networkManager.request(endpoint: "/users/mockuser1/repos", completion: { (result: Result<[GHRepository], Error>) in
            switch result {
            case .success(let repositories):
                XCTAssertEqual(repositories.count, 30)
                XCTAssertEqual(repositories.first?.name ?? "", "amqp")
                XCTAssertEqual(repositories.first?.language ?? "", "Ruby")
                XCTAssertEqual(repositories.first?.stargazers_count, 4)
                expectation.fulfill()
            case .failure:
                XCTFail("Expected success but got failure")
            }
        })
        
        wait(for: [expectation], timeout: 1.0)
    }
    
    func testAPICallWithError() {
        let mockError = NSError(domain: "00", code: 0, userInfo: nil)
        let mockSession = MockURLSession(data: nil, response: nil, error: mockError)
        let networkManager = NetworkManager(environment: .production, session: mockSession)
        
        let expectation = XCTestExpectation(description: "API call fails with error")
        
        networkManager.request(endpoint: "/repos", completion: { (result: Result<GHRepository, Error>) in
            switch result {
            case .success:
                XCTFail("Expected failure but got success")
            case .failure(let error):
                XCTAssertEqual((error as NSError).domain, "00")
                expectation.fulfill()
            }
        })
        
        wait(for: [expectation], timeout: 1.0)
    }
    
    func testInvalidHTTPStatusCode() {
        let mockResponse = HTTPURLResponse(
            url: URL(string: "https://api.github.com")!,
            statusCode: 404,
            httpVersion: nil,
            headerFields: nil
        )
        let mockSession = MockURLSession(data: nil, response: mockResponse, error: nil)
        let networkManager = NetworkManager(environment: .production, session: mockSession, useMockData: false)
        
        let expectation = XCTestExpectation(description: "API call fails with 404 error")
        
        networkManager.request(endpoint: "/repos", completion: { (result: Result<GHRepository, Error>) in
            switch result {
            case .success:
                XCTFail("Expected failure but got success")
            case .failure(let error):
                XCTAssertEqual(error as? NetworkError, NetworkError.notFound)
                expectation.fulfill()
            }
        })
        
        wait(for: [expectation], timeout: 1.0)
    }
    
    func testMissingToken() {
        let mockSession = MockURLSession(data: nil, response: nil, error: nil)
        let networkManager = NetworkManager(environment: .production, session: mockSession, useMockData: false, serviceToken: nil)
        
        let expectation = XCTestExpectation(description: "API call fails due to missing token")
        
        networkManager.request(endpoint: "/repos", completion: { (result: Result<GHRepository, Error>) in
            switch result {
            case .success:
                XCTFail("Expected failure but got success")
            case .failure(let error):
                XCTAssertEqual(error as? NetworkError, NetworkError.noToken)
                expectation.fulfill()
            }
        })
        
        wait(for: [expectation], timeout: 1.0)
    }
    
    func testNoDataInResponse() {
        let mockResponse = HTTPURLResponse(
            url: URL(string: "https://api.github.com")!,
            statusCode: 200,
            httpVersion: nil,
            headerFields: nil
        )
        let mockSession = MockURLSession(data: nil, response: mockResponse, error: nil)
        let networkManager = NetworkManager(environment: .production, session: mockSession, useMockData: false)
        
        let expectation = XCTestExpectation(description: "API call fails due to no data in response")
        
        networkManager.request(endpoint: "/repos", completion: { (result: Result<GHRepository, Error>) in
            switch result {
            case .success:
                XCTFail("Expected failure but got success")
            case .failure(let error):
                XCTAssertEqual(error as? NetworkError, NetworkError.noData)
                expectation.fulfill()
            }
        })
        
        wait(for: [expectation], timeout: 1.0)
    }
        
    func testUnauthorizedAccess() {
        let mockResponse = HTTPURLResponse(
            url: URL(string: "https://api.github.com")!,
            statusCode: 401,
            httpVersion: nil,
            headerFields: nil
        )
        let mockSession = MockURLSession(data: nil, response: mockResponse, error: nil)
        let networkManager = NetworkManager(environment: .production, session: mockSession, useMockData: false)
        
        let expectation = XCTestExpectation(description: "API call fails with 401 Unauthorized error")
        
        networkManager.request(endpoint: "/repos", completion: { (result: Result<GHRepository, Error>) in
            switch result {
            case .success:
                XCTFail("Expected failure but got success")
            case .failure(let error):
                XCTAssertEqual(error as? NetworkError, NetworkError.unauthorized)
                expectation.fulfill()
            }
        })
        
        wait(for: [expectation], timeout: 1.0)
    }
}
