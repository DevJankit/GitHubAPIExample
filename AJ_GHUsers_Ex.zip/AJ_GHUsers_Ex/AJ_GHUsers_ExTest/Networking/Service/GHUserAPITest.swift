//
//  GHUsersAPITests.swift
//  AJ_GHUsers_ExTests
//
//  Created by Ankit Jahagirdar on 05/05/25.
//

import XCTest
@testable import AJ_GHUsers_Ex

class GHUsersAPITests: XCTestCase {
    
    var usersAPI: GHUsersAPI!
    var mockNetworkManager: MockNetworkManager!
    
    override func setUp() {
        super.setUp()
        // Initialize mock network manager and users API before each test
        mockNetworkManager = MockNetworkManager()
        usersAPI = GHUsersAPI()
    }
    
    override func tearDown() {
        // Clean up resources after each test
        mockNetworkManager = nil
        usersAPI = nil
        super.tearDown()
    }
    
    // MARK: - Test Cases
    
    func testFetchUsersSuccess() {
        
        let expectation = XCTestExpectation(description: "Users are fetched successfully")
        
        usersAPI.fetchUsers { result in
            switch result {
            case .success(let users):
                XCTAssertEqual(users.count, 30)
                XCTAssertEqual(users.first?.login ?? "", "mockuser1")
                XCTAssertEqual(users.first?.avatar_url ?? "", "https://avatars.githubusercontent.com/u/1?v=4")
                expectation.fulfill()
            case .failure:
                XCTFail("Expected success but got failure")
            }
        }
        
        wait(for: [expectation], timeout: 1.0)
    }
    
    func testFetchUsersFailure() {
        let mockError = NSError(domain: "TestError", code: 1, userInfo: nil)
        mockNetworkManager.result = .failure(mockError)
        
        let expectation = XCTestExpectation(description: "Error is handled correctly")
        
        usersAPI.fetchUsers { result in
            // Assert
            switch result {
            case .success:
                XCTFail("Expected failure but got success") //Modify the mock data for failure case
            case .failure(let error):
                XCTAssertEqual(error.localizedDescription, mockError.localizedDescription)
                expectation.fulfill()
            }
        }
        
        wait(for: [expectation], timeout: 1.0)
    }
    
    func testFetchUserDetailsSuccess() {
        let expectation = XCTestExpectation(description: "User details are fetched successfully")
        
        usersAPI.fetchUserDetails(userName: "mockuser1") { result in
            // Assert
            switch result {
            case .success(let userDetail):
                XCTAssertEqual(userDetail.name ?? "", "monalisa octocat")
                XCTAssertEqual(userDetail.followers ?? 0, 20)
                XCTAssertEqual(userDetail.following ?? 0, 0)
                expectation.fulfill()
            case .failure:
                XCTFail("Expected success but got failure")
            }
        }
        
        wait(for: [expectation], timeout: 1.0)
    }
    
    func testFetchUserDetailsFailure() {
        let mockError = NSError(domain: "00", code: 0, userInfo: nil)
        mockNetworkManager.result = .failure(mockError)
        
        let expectation = XCTestExpectation(description: "Error is handled correctly")
        
        usersAPI.fetchUserDetails(userName: "testUser") { result in
            // Assert
            switch result {
            case .success:
                XCTFail("Expected failure but got success") //Modify mock response to simulate failures from json file.
            case .failure(let error):
                XCTAssertEqual(error.localizedDescription, mockError.localizedDescription)
                expectation.fulfill()
            }
        }
        
        wait(for: [expectation], timeout: 1.0)
    }
}
