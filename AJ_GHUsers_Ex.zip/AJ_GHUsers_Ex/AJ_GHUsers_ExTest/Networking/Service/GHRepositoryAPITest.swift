//
//  GHRepositoryAPITests.swift
//  AJ_GHUsers_ExTests
//
//  Created by Ankit Jahagirdar on 05/05/25.
//

import XCTest
@testable import AJ_GHUsers_Ex

class GHRepositoryAPITests: XCTestCase {
    
    var repositoryAPI: GHRepositoryAPI!
    var mockNetworkManager: MockRepositoryNetworkManager!
    
    override func setUp() {
        super.setUp()
        mockNetworkManager = MockRepositoryNetworkManager()
        repositoryAPI = GHRepositoryAPI()
    }
    
    override func tearDown() {
        mockNetworkManager = nil
        repositoryAPI = nil
        super.tearDown()
    }
    
    // MARK: - Test Cases
    
    func testFetchRepositoriesSuccess() {

        let expectation = XCTestExpectation(description: "Repositories are fetched successfully")
        
        repositoryAPI.fetchRepositories(userName: "mockuser1") { result in
            switch result {
            case .success(let repositories):
                XCTAssertEqual(repositories.count, 30)
                XCTAssertEqual(repositories.first?.name ?? "", "amqp")
                XCTAssertEqual(repositories.first?.language ?? "", "Ruby")
                XCTAssertEqual(repositories.first?.stargazers_count, 4)
                expectation.fulfill()
            case .failure:
                XCTFail("Expected success but got failure")
            }
        }
        
        wait(for: [expectation], timeout: 1.0)
    }
    
    func testFetchRepositoriesFailure() {
        let mockError = NSError(domain: "00", code: 0, userInfo: nil)
        mockNetworkManager.result = .failure(mockError)
        
        let expectation = XCTestExpectation(description: "Error is handled correctly")
        
        repositoryAPI.fetchRepositories(userName: "testUser") { result in
            switch result {
            case .success:
                XCTFail("Expected failure but got success")
            case .failure(let error):
                XCTAssertEqual(error.localizedDescription, mockError.localizedDescription)
                expectation.fulfill()
            }
        }
        
        wait(for: [expectation], timeout: 1.0)
    }
}

// MARK: - Mock Classes
class MockRepositoryNetworkManager: NetworkManagerProtocol {
    var result: Result<[GHRepository], Error>!
    
    func request<T: Decodable>(
        endpoint: String,
        method: String,
        parameters: [String: String]?,
        completion: @escaping (Result<T, Error>) -> Void
    ) {
        if let result = result as? Result<T, Error> {
            completion(result)
        }
    }
}
