//
//  GHRateLimitAPITests.swift
//  AJ_GHUsers_ExTests
//
//  Created by Ankit Jahagirdar on 05/05/25.
//

import XCTest
@testable import AJ_GHUsers_Ex

class GHRateLimitAPITests: XCTestCase {
    
    var rateLimitAPI: GHRateLimitAPI!
    var mockNetworkManager: MockRateLimitAPINetworkManager!
    
    override func setUp() {
        super.setUp()
        mockNetworkManager = MockRateLimitAPINetworkManager()
        rateLimitAPI = GHRateLimitAPI()
    }
    
    override func tearDown() {
        mockNetworkManager = nil
        rateLimitAPI = nil
        super.tearDown()
    }
    
    // MARK: - Test Cases
    
    func testFetchRateLimitSuccess() {
        let expectation = XCTestExpectation(description: "Rate limit is fetched successfully")
        
        rateLimitAPI.fetchRateLimit { result in
            // Assert
            switch result {
            case .success(let response):
                XCTAssertEqual(response.rate?.remaining, 5000)
                expectation.fulfill()
            case .failure:
                XCTFail("Expected success but got failure")
            }
        }
        
        wait(for: [expectation], timeout: 1.0)
    }
    
    func testFetchRateLimitFailure() {
        let mockError = NSError(domain: "00", code: 0, userInfo: nil)
        mockNetworkManager.result = .failure(mockError)
        
        let expectation = XCTestExpectation(description: "Error is handled correctly")
        
        rateLimitAPI.fetchRateLimit { result in
            // Assert
            switch result {
            case .success:
                XCTFail("Expected failure but got success")
            case .failure(let error):
                XCTAssertEqual(error.localizedDescription, mockError.localizedDescription)
                expectation.fulfill()
            }
        }
        
        wait(for: [expectation], timeout: 1.0)
    }
}

// MARK: - Mock Classes

class MockRateLimitAPINetworkManager: NetworkManagerProtocol {
    var result: Result<GHRateLimitResponse, Error>!
    
    func request<T: Decodable>(
        endpoint: String,
        method: String,
        parameters: [String: String]?,
        completion: @escaping (Result<T, Error>) -> Void
    ) {
        if let result = result as? Result<T, Error> {
            completion(result)
        }
    }
}
