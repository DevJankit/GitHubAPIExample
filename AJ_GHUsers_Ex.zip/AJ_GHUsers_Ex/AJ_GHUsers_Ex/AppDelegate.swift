//
//  AppDelegate.swift
//  AJ_GHUsers_Ex
//
//  Created by Ankit Jahagirdar on 01/05/25.
//

import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var window: UIWindow?

    func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
    ) -> Bool {
        
        NetworkConfig.shared.environment = .development
        
        window = UIWindow(frame: UIScreen.main.bounds)
        
        let navigationController = UINavigationController()
        let rootVC = createUserVC(navigationVC: navigationController)
        navigationController.viewControllers = [rootVC]
        window?.rootViewController = navigationController
        
        window?.makeKeyAndVisible()
        
        return true
    }
    
    //Method to set the controller as root controller
    func createUserVC(navigationVC: UINavigationController) -> UIViewController {
        let usersAPI = GHUsersAPI()
        let rateLimitAPI = GHRateLimitAPI()
        let viewModel = UserListViewModel(usersAPI: usersAPI, rateLimitAPI: rateLimitAPI)
        let userListVC = UserListVC(viewModel: viewModel, coordinator: UserListCoordinator(navigationController: navigationVC))
        return userListVC
    }
}

