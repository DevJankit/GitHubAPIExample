//
//  Logger.swift
//  AJ_GHUsers_Ex
//
//  Created by Ankit Jahagirdar on 03/05/25.
//

import os

let logger = Logger(subsystem: "com.working.ghusersapp", category: "Common")
