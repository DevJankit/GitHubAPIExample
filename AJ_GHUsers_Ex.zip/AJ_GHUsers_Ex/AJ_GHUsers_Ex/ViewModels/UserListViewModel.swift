//
//  UserListViewModel.swift
//  AJ_GHUsers_Ex
//
//  Created by Ankit Jahagirdar on 03/05/25.
//

protocol UserListViewModelProtocol {
    var users: [GHUser] { get }
    var onUsersUpdated: (() -> Void)? { get set }
    var onError: ((String) -> Void)? { get set }
    var isLoading: ((Bool) -> Void)? { get set }

    func fetchUsers()
    func checkRateLimitAndFetchUsers()
}

class UserListViewModel: UserListViewModelProtocol {
    private let usersAPI: GHUsersAPIProtocol
    private let rateLimitAPI: GHRateLimitAPIProtocol

    var users: [GHUser] = [] {
        didSet {
            onUsersUpdated?()
        }
    }

    var onUsersUpdated: (() -> Void)?
    var onError: ((String) -> Void)?
    var isLoading: ((Bool) -> Void)?

    init(usersAPI: GHUsersAPIProtocol, rateLimitAPI: GHRateLimitAPIProtocol) {
        self.usersAPI = usersAPI
        self.rateLimitAPI = rateLimitAPI
    }

    func fetchUsers() {
        isLoading?(true)
        usersAPI.fetchUsers { [weak self] result in
            self?.isLoading?(false)
            switch result {
            case .success(let userList):
                self?.users = userList
            case .failure(let error):
                self?.onError?(error.localizedDescription)
            }
        }
    }

    func checkRateLimitAndFetchUsers() {
        rateLimitAPI.fetchRateLimit { [weak self] result in
            switch result {
            case .success(let response):
                
                let remaining = response.rate?.remaining ?? 0
                
                if remaining > 0 {
                    self?.fetchUsers()
                } else {
                    self?.onError?("Rate limit exceeded. Please try again later.")
                }
            case .failure(let error):
                self?.onError?("Error fetching rate limit: \(error.localizedDescription)")
            }
        }
    }
}
