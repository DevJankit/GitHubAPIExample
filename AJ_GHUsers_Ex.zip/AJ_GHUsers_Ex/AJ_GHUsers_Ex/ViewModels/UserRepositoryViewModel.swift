//
//  UserRepositoryViewModel.swift
//  AJ_GHUsers_Ex
//
//  Created by Ankit Jahagirdar on 04/05/25.
//

protocol UserRepositoryViewModelProtocol {
    var user: GHUser { get }
    var repositories: [GHRepository] { get }
    var userDetails: GHUserDetail? { get }
    
    var onRepositoriesUpdated: (() -> Void)? { get set }
    var onError: ((String) -> Void)? { get set }
    var onUserDetailsUpdated: (() -> Void)? { get set }
    var isLoading: ((Bool) -> Void)? { get set }
    
    func fetchUserDetails()
    func fetchRepositories()
}

class UserRepositoryViewModel: UserRepositoryViewModelProtocol {
    
    private let repositoryAPI: GHRepositoryAPIProtocol
    private let userAPI: GHUsersAPIProtocol
    var user: GHUser

    var repositories: [GHRepository] = []
    
    var userDetails : GHUserDetail?

    var onRepositoriesUpdated: (() -> Void)?
    var onUserDetailsUpdated: (() -> Void)?
    var onError: ((String) -> Void)?
    var isLoading: ((Bool) -> Void)?

    init(user: GHUser, repositoryAPI: GHRepositoryAPIProtocol, userAPI: GHUsersAPIProtocol) {
        self.user = user
        self.userAPI = userAPI
        self.repositoryAPI = repositoryAPI
    }
    
    //TODO: - Write a DispatchGroup to fetch user details and repository data at once.
    func fetchUserDetails() {
        
        guard let userLogin = user.login, userLogin != "" else {
            
            onError?("User data missing")
            return
        }
        userAPI.fetchUserDetails(userName: userLogin) { [weak self] result in
            switch result {
            case .success(let userDetails):
                self?.userDetails = userDetails
                self?.onUserDetailsUpdated?()
            case .failure(let error):
                print("Failed to fetch user details: \(error)")
            }
        }
    }

    func fetchRepositories() {
        
        isLoading?(true)
        guard let userLogin = user.login, userLogin != "" else {
            
            onError?("User data missing")
            return
        }
        
        repositoryAPI.fetchRepositories(userName: userLogin) { [weak self] result in
            self?.isLoading?(false)
            switch result {
            case .success(let repositoryList):
                self?.repositories = repositoryList.filter { !($0.fork ?? false) }
                self?.onRepositoriesUpdated?()
            case .failure(let error):
                self?.onError?(error.localizedDescription)
            }
        }
    }
}
