//
//  Viewcontroller+Addition.swift
//  AJ_GHUsers_Ex
//
//  Created by Ankit Jahagirdar on 01/05/25.
//

import UIKit

extension UIViewController {
    
    func showErrorAlert(message: String) {
        DispatchQueue.main.async {
            let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            self.present(alert, animated: true)
        }
    }
    
}
