//
//  GHRepositoryModel.swift
//  AJ_GHUsers_Ex
//
//  Created by Ankit Jahagirdar on 01/05/25.
//

struct GHRepository: Codable {
    let name: String?
    let language: String?
    let stargazers_count: Int?
    let description: String?
    let html_url: String?
    let fork: Bool?
}
