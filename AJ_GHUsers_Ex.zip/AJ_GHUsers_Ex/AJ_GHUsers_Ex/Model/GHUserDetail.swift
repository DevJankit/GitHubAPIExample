//
//  GHUserDetail.swift
//  AJ_GHUsers_Ex
//
//  Created by Ankit Jahagirdar on 04/05/25.
//

struct GHUserDetail: Codable {
    let login: String?
    let avatar_url: String?
    let name: String?
    let followers: Int?
    let following: Int?
}
