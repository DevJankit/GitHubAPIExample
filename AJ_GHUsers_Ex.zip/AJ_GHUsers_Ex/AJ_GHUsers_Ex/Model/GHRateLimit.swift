//
//  GHRateLimitResponse.swift
//  AJ_GHUsers_Ex
//
//  Created by Ankit Jahagirdar on 01/05/25.
//

struct GHRateLimitResponse: Decodable {
    let rate: GHRate?

    struct GHRate: Decodable {
        let remaining: Int?
    }
}
