//
//  NetworkMocker.swift
//  AJ_GHUsers_Ex
//
//  Created by Ankit Jahagirdar on 01/05/25.
//

import Foundation

class MockDataProvider {
    
    static let shared = MockDataProvider()

    // Mock JSON response
    // Below is used during testing to avoid hitting the API due to limited tokens.
    func getMockResponse(for endpoint: String) -> Data? {
        switch endpoint {
        case "/users":
            if let data = try? StaticJSONMapper.decode(file: "userListMock") {
                return data
            }
            else {
                return nil
            }
            
        case "/users/mockuser1/repos":
            if let data = try? StaticJSONMapper.decode(file: "repoMock") {
                return data
            }
            else {
                return nil
            }
            
        case "/users/mockuser1":
            if let data = try? StaticJSONMapper.decode(file: "userDetailMock") {
                return data
            }
            else {
                return nil
            }
            
        case "/rate_limit":
            return """
            {
            "rate" : {
                "limit": 5000,
                "remaining": 5000,
                "reset" : 1746127735,
                "used": 0
            }
        }
        """.data(using: .utf8)
        //return nil //nil or custom data can be returned here for testing

        default:
            return nil
        }
    }
}
