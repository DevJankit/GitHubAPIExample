//
//  UsersAPI.swift
//  AJ_GHUsers_Ex
//
//  Created by Ankit Jahagirdar on 01/05/25.
//

protocol GHUsersAPIProtocol {
    func fetchUsers(completion: @escaping (Result<[GHUser], Error>) -> Void)
    func fetchUserDetails(userName: String, completion: @escaping (Result<GHUserDetail, Error>) -> Void)
}

class GHUsersAPI : GHUsersAPIProtocol {
    
    func fetchUsers(completion: @escaping (Result<[GHUser], Error>) -> Void) {
        NetworkManager().request(endpoint: "/users") { (result: Result<[GHUser], Error>) in
            
            completion(result)
        }
    }
    
    func fetchUserDetails(userName: String, completion: @escaping (Result<GHUserDetail, Error>) -> Void) {
        
        let endpoint = "/users/\(userName)"
        NetworkManager().request(endpoint: endpoint) { (result: Result<GHUserDetail, Error>) in
            
            completion(result)
        }
    }
}
