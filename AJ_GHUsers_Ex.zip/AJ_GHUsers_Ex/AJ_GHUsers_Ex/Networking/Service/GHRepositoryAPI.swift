//
//  GHRepositoriesAPI.swift
//  AJ_GHUsers_Ex
//
//  Created by Ankit Jahagirdar on 01/05/25.
//

protocol GHRepositoryAPIProtocol {
    func fetchRepositories(userName: String, completion: @escaping (Result<[GHRepository], Error>) -> Void)
}

class GHRepositoryAPI : GHRepositoryAPIProtocol {
    
    func fetchRepositories(userName: String,  completion: @escaping (Result<[GHRepository], Error>) -> Void) {
        
        let endpoint = "/users/\(userName)/repos"
        NetworkManager().request(endpoint: endpoint) { (result: Result<[GHRepository], Error>) in
            switch result {
            case .success(let userRepos):
                completion(.success(userRepos))
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }
}
