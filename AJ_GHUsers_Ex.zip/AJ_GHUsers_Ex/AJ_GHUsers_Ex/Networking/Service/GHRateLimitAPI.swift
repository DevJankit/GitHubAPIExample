//
//  GHRateLimitAPI.swift
//  AJ_GHUsers_Ex
//
//  Created by Ankit Jahagirdar on 01/05/25.
//

protocol GHRateLimitAPIProtocol {
    func fetchRateLimit(completion: @escaping (Result<GHRateLimitResponse, Error>) -> Void)
}

class GHRateLimitAPI : GHRateLimitAPIProtocol{
    
    func fetchRateLimit(completion: @escaping (Result<GHRateLimitResponse, Error>) -> Void) {
        NetworkManager().request(endpoint: "/rate_limit") { (result: Result<GHRateLimitResponse, Error>) in
            switch result {
            case .success(let response):
                completion(.success(response))
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }
}
