//
//  NetworkError.swift
//  AJ_GHUsers_Ex
//
//  Created by Ankit Jahagirdar on 01/05/25.
//

enum NetworkError: Error {
    case invalidURL
    case invalidResponse
    case noData
    case noToken
    case unauthorized
    case forbidden
    case serverError
    case badRequest
    case notFound
    case unknown
}
