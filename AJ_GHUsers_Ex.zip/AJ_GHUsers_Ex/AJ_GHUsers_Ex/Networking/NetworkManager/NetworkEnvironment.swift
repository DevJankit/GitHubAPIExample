//
//  NetworkEnvironment.swift
//  AJ_GHUsers_Ex
//
//  Created by Ankit Jahagirdar on 03/05/25.
//

enum Environment {
    case development
    case production

    var baseURL: String {
        switch self {
        case .development:
            return "https://api.github.com"
        case .production:
            return "https://api.github.com"
        }
    }
}

//TODO: Below class can be replaced by linking it to development and production schemes.
class NetworkConfig {
    static let shared = NetworkConfig()
    var environment: Environment = .production // Default environment

    private init() {}
}
