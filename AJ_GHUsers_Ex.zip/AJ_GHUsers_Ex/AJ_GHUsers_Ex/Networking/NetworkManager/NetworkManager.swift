import Foundation

protocol NetworkManagerProtocol {
    func request<T: Decodable>(
        endpoint: String,
        method: String,
        parameters: [String: String]?,
        completion: @escaping (Result<T, Error>) -> Void
    )
}

class NetworkManager: NetworkManagerProtocol {
    
    private let environment: Environment
    private let session: URLSession
    private let useMockData: Bool
    private let serviceToken: String?

    init(environment: Environment = .production, session: URLSession = .shared, useMockData: Bool = false, serviceToken: String? = ProcessInfo.processInfo.environment["GH_Dev_Token"]) {
        self.environment = environment
        self.session = session
        self.useMockData = useMockData
        self.serviceToken = serviceToken
    }
    
    func request<T: Decodable>(
        endpoint: String,
        method: String = "GET",
        parameters: [String: String]? = nil,
        completion: @escaping (Result<T, Error>) -> Void
    ) {
        if handleMockData(for: endpoint, completion: completion) {
            return
        }
        
        guard let token = serviceToken, !token.isEmpty else {
            completion(.failure(NetworkError.noToken))
            return
        }

        guard let url = buildURL(endpoint: endpoint, parameters: parameters) else {
            completion(.failure(NetworkError.invalidURL))
            return
        }

        let request = createRequest(url: url, method: method, token: token)

        session.dataTask(with: request) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }

            guard let httpResponse = response as? HTTPURLResponse else {
                completion(.failure(NetworkError.invalidResponse))
                return
            }

            switch httpResponse.statusCode {
            case 200...299:
                break
            case 400:
                completion(.failure(NetworkError.badRequest))
                return
            case 401:
                completion(.failure(NetworkError.unauthorized))
                return
            case 404:
                completion(.failure(NetworkError.notFound))
                return
            case 500:
                completion(.failure(NetworkError.serverError))
                return
            default:
                completion(.failure(NetworkError.unknown))
                return
            }

            guard let data = data else {
                completion(.failure(NetworkError.noData))
                return
            }

            do {
                let decodedData = try JSONDecoder().decode(T.self, from: data)
                completion(.success(decodedData))
            } catch {
                completion(.failure(error))
            }
        }.resume()
    }

    private func handleMockData<T: Decodable>(for endpoint: String, completion: @escaping (Result<T, Error>) -> Void) -> Bool {
        if useMockData {
            guard let mockData = MockDataProvider.shared.getMockResponse(for: endpoint) else {
                completion(.failure(NSError(domain: "00", code: 0, userInfo: nil)))
                return true
            }
            do {
                let decodedData = try JSONDecoder().decode(T.self, from: mockData)
                completion(.success(decodedData))
            } catch let error {
                completion(.failure(error))
            }
            return true
        }
        return false
    }

    private func buildURL(endpoint: String, parameters: [String: String]?) -> URL? {
        var components = URLComponents(string: environment.baseURL + endpoint)
        if let parameters = parameters {
            components?.queryItems = parameters.map { URLQueryItem(name: $0.key, value: $0.value) }
        }
        return components?.url
    }
    
    private func createRequest(url: URL, method: String, token: String) -> URLRequest {
        
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        return request
    }
}
