//
//  UserHeaderView.swift
//  AJ_GHUsers_Ex
//
//  Created by Ankit Jahagirdar on 04/05/25.
//

import UIKit

class UserHeaderView: UIView {
    private let iconImageView = UIImageView()
    private let userNameLabel = UILabel()
    private let fullNameLabel = UILabel()
    private let followersLabel = UILabel()
    private let followingLabel = UILabel()
    private let containerView = UIView()

    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupView() {
        containerView.translatesAutoresizingMaskIntoConstraints = false
        containerView.backgroundColor = UIColor.systemGray6
        containerView.layer.cornerRadius = 12
        containerView.layer.shadowColor = UIColor.black.cgColor
        containerView.layer.shadowOpacity = 0.1
        containerView.layer.shadowOffset = CGSize(width: 0, height: 2)
        containerView.layer.shadowRadius = 4
        addSubview(containerView)

        iconImageView.contentMode = .scaleAspectFill
        iconImageView.layer.cornerRadius = 40
        iconImageView.clipsToBounds = true
        iconImageView.translatesAutoresizingMaskIntoConstraints = false

        userNameLabel.font = UIFont.boldSystemFont(ofSize: 20)
        userNameLabel.textColor = .black
        userNameLabel.textAlignment = .center

        fullNameLabel.font = UIFont.systemFont(ofSize: 16, weight: .medium)
        fullNameLabel.textColor = .darkGray
        fullNameLabel.textAlignment = .center

        followersLabel.font = UIFont.systemFont(ofSize: 15, weight: .medium)
        followersLabel.textColor = .gray
        followersLabel.textAlignment = .center

        followingLabel.font = UIFont.systemFont(ofSize: 15, weight: .medium)
        followingLabel.textColor = .gray
        followingLabel.textAlignment = .center

        let stackView = UIStackView(arrangedSubviews: [iconImageView, userNameLabel, fullNameLabel, followersLabel, followingLabel])
        stackView.axis = .vertical
        stackView.spacing = 10
        stackView.alignment = .center
        stackView.translatesAutoresizingMaskIntoConstraints = false
        containerView.addSubview(stackView)

        NSLayoutConstraint.activate([
            containerView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16),
            containerView.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16),
            containerView.topAnchor.constraint(equalTo: topAnchor, constant: 16),
            containerView.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -16),

            stackView.centerXAnchor.constraint(equalTo: containerView.centerXAnchor),
            stackView.centerYAnchor.constraint(equalTo: containerView.centerYAnchor),
            stackView.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 16),
            stackView.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -16),

            iconImageView.widthAnchor.constraint(equalToConstant: 80),
            iconImageView.heightAnchor.constraint(equalToConstant: 80)
        ])
    }

    func configure(with user: GHUserDetail?) {
        userNameLabel.text = user?.login ?? "Username"
        fullNameLabel.text = user?.name ?? "Full Name"
        followersLabel.text = "Followers: \(user?.followers ?? 0)"
        followingLabel.text = "Following: \(user?.following ?? 0)"
        
        guard let avatarUrl = user?.avatar_url, avatarUrl != "" else {
            iconImageView.image = UIImage(systemName: "person.fill")
            return
        }
        iconImageView.loadImage(from: avatarUrl, placeholder: UIImage(systemName: "person.fill"))
    }
}
