//
//  ErrorView.swift
//  AJ_GHUsers_Ex
//
//  Created by Ankit Jahagirdar on 05/05/25.
//
import UIKit

class ErrorView: UIView {
    let messageLabel = UILabel()

    init() {
        super.init(frame: .zero)
        setupView()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupView() {
        messageLabel.translatesAutoresizingMaskIntoConstraints = false
        messageLabel.textAlignment = .center
        messageLabel.textColor = .gray
        addSubview(messageLabel)

        NSLayoutConstraint.activate([
            messageLabel.centerXAnchor.constraint(equalTo: centerXAnchor),
            messageLabel.centerYAnchor.constraint(equalTo: centerYAnchor)
        ])
    }

    func configure(with message: String) {
        messageLabel.text = message
    }
}
