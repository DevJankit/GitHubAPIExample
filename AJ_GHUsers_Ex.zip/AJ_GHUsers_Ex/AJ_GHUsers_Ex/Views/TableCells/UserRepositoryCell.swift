//
//  UserRepositoryCell.swift
//  AJ_GHUsers_Ex
//
//  Created by Ankit Jahagirdar on 03/05/25.
//

import UIKit

class UserRepositoryCell: UITableViewCell {
    private let containerView = UIView()
    private let nameLabel = UILabel()
    private let languageLabel = UILabel()
    private let starsLabel = UILabel()
    private let descriptionLabel = UILabel()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupViews()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupViews() {
        containerView.translatesAutoresizingMaskIntoConstraints = false
        containerView.backgroundColor = .white
        containerView.layer.cornerRadius = 10
        containerView.layer.shadowColor = UIColor.black.cgColor
        containerView.layer.shadowOpacity = 0.1
        containerView.layer.shadowOffset = CGSize(width: 0, height: 2)
        containerView.layer.shadowRadius = 4
        contentView.addSubview(containerView)

        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        nameLabel.font = UIFont.systemFont(ofSize: 18, weight: .bold)
        nameLabel.textColor = .black
        nameLabel.numberOfLines = 0
        containerView.addSubview(nameLabel)

        languageLabel.translatesAutoresizingMaskIntoConstraints = false
        languageLabel.font = UIFont.systemFont(ofSize: 14, weight: .medium)
        languageLabel.textColor = .darkGray
        containerView.addSubview(languageLabel)

        starsLabel.translatesAutoresizingMaskIntoConstraints = false
        starsLabel.font = UIFont.systemFont(ofSize: 15, weight: .medium)
        starsLabel.textColor = .darkGray
        containerView.addSubview(starsLabel)

        descriptionLabel.translatesAutoresizingMaskIntoConstraints = false
        descriptionLabel.font = UIFont.systemFont(ofSize: 14, weight: .regular)
        descriptionLabel.textColor = .gray
        descriptionLabel.numberOfLines = 0
        containerView.addSubview(descriptionLabel)

        // setu constraints
        NSLayoutConstraint.activate([
            containerView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 10),
            containerView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -10),
            containerView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 10),
            containerView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -10),

            nameLabel.topAnchor.constraint(equalTo: containerView.topAnchor, constant: 15),
            nameLabel.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 15),
            nameLabel.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -15),

            languageLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 10),
            languageLabel.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 15),

            starsLabel.centerYAnchor.constraint(equalTo: languageLabel.centerYAnchor),
            starsLabel.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -15),

            descriptionLabel.topAnchor.constraint(equalTo: languageLabel.bottomAnchor, constant: 10),
            descriptionLabel.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 15),
            descriptionLabel.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -15),
            descriptionLabel.bottomAnchor.constraint(equalTo: containerView.bottomAnchor, constant: -15)
        ])
    }

    //Configure the values received from the controller
    func configure(with repo: GHRepository) {
        nameLabel.text = repo.name ?? "No Name"
        languageLabel.text = "Language: \(repo.language ?? "N/A")"
        starsLabel.text = "⭐️ \(repo.stargazers_count ?? 0)"
        descriptionLabel.text = repo.description ?? "No description available."
    }
}
