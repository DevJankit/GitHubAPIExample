//
//  UserListVC.swift
//  AJ_GHUsers_Ex
//
//  Created by Ankit Jahagirdar on 01/05/25.
//

import UIKit

class UserListVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    let tableView = UITableView()
    var viewModel: UserListViewModelProtocol
    let loader = UIActivityIndicatorView(style: .large)
    let errorView = ErrorView()
    let coordinator: UserListCoordinatorProtocol

    init(viewModel: UserListViewModelProtocol, coordinator: UserListCoordinatorProtocol) {
        self.viewModel = viewModel
        self.coordinator = coordinator
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Users"
        view.backgroundColor = .white
        setupTableView()
        setupLoader()
        bindViewModel()
        fetchData()
    }

    // MARK: - UI Setup methods
    private func setupTableView() {
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UserListCell.self, forCellReuseIdentifier: "UserListCell")
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 100
        tableView.frame = view.bounds
        tableView.separatorStyle = .none
        view.addSubview(tableView)
    }

    private func setupLoader() {
        loader.center = view.center
        loader.hidesWhenStopped = true
        view.addSubview(loader)
    }
    
     private func setupErrorView() {
        errorView.translatesAutoresizingMaskIntoConstraints = false
        errorView.isHidden = true
        view.addSubview(errorView)

        NSLayoutConstraint.activate([
            errorView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            errorView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            errorView.topAnchor.constraint(equalTo: view.topAnchor),
            errorView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }

    // MARK: - ViewModel Methods
    private func bindViewModel() {
        
        viewModel.isLoading = { [weak self] isLoading in
            DispatchQueue.main.async {
                isLoading ? self?.loader.startAnimating() : self?.loader.stopAnimating()
            }
        }
        
        viewModel.onUsersUpdated = { [weak self] in
            DispatchQueue.main.async {
                self?.loader.stopAnimating()
                if self?.viewModel.users.isEmpty == true {
                    self?.setupErrorView()
                    self?.showErrorView(message: "No data available. Please try again.")
                } else {
                    self?.tableView.reloadData()
                }
            }
        }

        viewModel.onError = { [weak self] errorMessage in
            DispatchQueue.main.async {
                self?.loader.stopAnimating()
                self?.showErrorView(message: errorMessage)
            }
        }
    }

    func fetchData() {
        loader.startAnimating()
        viewModel.checkRateLimitAndFetchUsers()
    }

    // MARK: - ErrorView methods
    private func showErrorView(message: String) {
        errorView.configure(with: message)
        errorView.isHidden = false
        tableView.isHidden = true
    }

    private func hideErrorView() {
        errorView.isHidden = true
        tableView.isHidden = false
    }

    // MARK: - TableView DataSource
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.users.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "UserListCell", for: indexPath) as! UserListCell
        let user = viewModel.users[indexPath.row]
        cell.configure(with: user)
        return cell
    }

    // MARK: - TableView Delegate
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let user = viewModel.users[indexPath.row]
        coordinator.navigateToUserRepository(user: user)
        tableView.deselectRow(at: indexPath, animated: true)
    }
}
