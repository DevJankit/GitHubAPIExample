//
//  UserRepositoryVC.swift
//  AJ_GHUsers_Ex
//
//  Created by Ankit Jahagirdar on 01/05/25.
//

//
//  UserRepositoryVC.swift
//  AJ_GHUsers_Ex
//
//  Created by Ankit Jahagirdar on 01/05/25.
//

import UIKit

class UserRepositoryVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    private let tableView = UITableView()
    private var viewModel: UserRepositoryViewModelProtocol
    private let userHeaderView = UserHeaderView()
    private var headerHeight: CGFloat = 0
    private let loader = UIActivityIndicatorView(style: .large)
    private let errorView = ErrorView()
    private let coordinator: UserRepositoryCoordinatorProtocol

    init(viewModel: UserRepositoryViewModelProtocol, coordinator: UserRepositoryCoordinatorProtocol) {
        self.viewModel = viewModel
        self.coordinator = coordinator
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = viewModel.user.login
        view.backgroundColor = .white
        setupTableView()
        setupUserHeaderView()
        setupLoader()
        setupErrorView()
        bindViewModel()
        fetchData()
    }

    // MARK: - UI Setup Methods
    private func setupTableView() {
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UserRepositoryCell.self, forCellReuseIdentifier: "UserRepositoryCell")
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 100
        tableView.frame = view.bounds
        tableView.separatorStyle = .none
        view.addSubview(tableView)
    }

    private func setupUserHeaderView() {
        userHeaderView.frame = CGRect(x: 0, y: 0, width: view.bounds.width, height: headerHeight)
        userHeaderView.isHidden = true
        tableView.tableHeaderView = userHeaderView
    }

    private func setupLoader() {
        loader.center = view.center
        loader.hidesWhenStopped = true
        view.addSubview(loader)
    }

    private func setupErrorView() {
        errorView.translatesAutoresizingMaskIntoConstraints = false
        errorView.isHidden = true
        view.addSubview(errorView)

        NSLayoutConstraint.activate([
            errorView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            errorView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            errorView.topAnchor.constraint(equalTo: view.topAnchor),
            errorView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }

    private func bindViewModel() {
        viewModel.isLoading = { [weak self] isLoading in
            DispatchQueue.main.async {
                isLoading ? self?.loader.startAnimating() : self?.loader.stopAnimating()
            }
        }

        viewModel.onRepositoriesUpdated = { [weak self] in
            DispatchQueue.main.async {
                self?.loader.stopAnimating()
                if self?.viewModel.repositories.isEmpty == true {
                    self?.showErrorView(message: "No repositories available.")
                } else {
                    self?.hideErrorView()
                    self?.tableView.reloadData()
                }
            }
        }

        viewModel.onError = { [weak self] errorMessage in
            DispatchQueue.main.async {
                self?.loader.stopAnimating()
                self?.showErrorView(message: errorMessage)
            }
        }

        viewModel.onUserDetailsUpdated = { [weak self] in
            DispatchQueue.main.async {
                self?.headerHeight = 250
                self?.userHeaderView.frame = CGRect(x: 0, y: 0, width: self?.view.bounds.width ?? 0, height: self?.headerHeight ?? 0)
                self?.userHeaderView.isHidden = false
                self?.userHeaderView.configure(with: self?.viewModel.userDetails)
            }
        }
    }

    private func fetchData() {
        viewModel.fetchRepositories()
        viewModel.fetchUserDetails()
    }

    // MARK: - ErrorView Methods
    private func showErrorView(message: String) {
        errorView.configure(with: message)
        errorView.isHidden = false
        tableView.isHidden = true
    }

    private func hideErrorView() {
        errorView.isHidden = true
        tableView.isHidden = false
    }

    // MARK: - TableView DataSource
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.repositories.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "UserRepositoryCell", for: indexPath) as! UserRepositoryCell
        let repo = viewModel.repositories[indexPath.row]
        cell.configure(with: repo)
        return cell
    }

    // MARK: - TableView Delegate
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let repo = viewModel.repositories[indexPath.row]
        coordinator.navigateToWebView(url: repo.html_url ?? "")
        tableView.deselectRow(at: indexPath, animated: true)
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }

}
