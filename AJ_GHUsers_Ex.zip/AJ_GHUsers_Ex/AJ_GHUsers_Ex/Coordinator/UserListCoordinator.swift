//
//  UserListCoordinator.swift
//  AJ_GHUsers_Ex
//
//  Created by Ankit Jahagirdar on 05/05/25.
//

import Foundation
import UIKit

protocol UserListCoordinatorProtocol {
    func navigateToUserRepository(user: GHUser)
}

class UserListCoordinator: UserListCoordinatorProtocol {
    private let navigationController: UINavigationController

    init(navigationController: UINavigationController) {
        self.navigationController = navigationController
    }

    func navigateToUserRepository(user: GHUser) {
        let repositoryAPI = GHRepositoryAPI()
        let userDetailsAPI = GHUsersAPI()
        let viewModel = UserRepositoryViewModel(user: user, repositoryAPI: repositoryAPI, userAPI: userDetailsAPI)
        let userRepositoryVC = UserRepositoryVC(viewModel: viewModel, coordinator: UserRepositoryCoordinator(navigationController: navigationController))
        navigationController.pushViewController(userRepositoryVC, animated: true)
    }
}
