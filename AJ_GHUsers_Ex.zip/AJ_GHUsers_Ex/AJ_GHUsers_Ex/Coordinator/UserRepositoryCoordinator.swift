//
//  UserRepositoryCoordinator.swift
//  AJ_GHUsers_Ex
//
//  Created by Ankit Jahagirdar on 05/05/25.
//

import UIKit

protocol UserRepositoryCoordinatorProtocol {
    func navigateToWebView(url: String)
}

class UserRepositoryCoordinator: UserRepositoryCoordinatorProtocol {
    private let navigationController: UINavigationController
    
    init(navigationController: UINavigationController) {
        self.navigationController = navigationController
    }
    
    func navigateToWebView(url: String) {
        let webVC = WebViewVC(url: url)
        navigationController.pushViewController(webVC, animated: true)
    }
}
